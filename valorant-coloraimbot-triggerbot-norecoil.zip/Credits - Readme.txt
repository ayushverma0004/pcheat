Credits for the Aimbot Source to Voluminoso
Credits for the Triggerbot Source to jamz256
Credits for the NoRecoil Source to KratosHaynes

*Recoded* by Baseult